# AnuCore real AI

The existing AnuCore design is preserved. Run and Ask now call `/api/chat`.

Keep `OPENAI_API_KEY` server-side. Do not put it in `index.html`.

Deploy this project on Vercel, then add an Environment Variable named
`OPENAI_API_KEY` with your API key. Optionally set `OPENAI_MODEL`.
