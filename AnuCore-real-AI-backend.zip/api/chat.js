import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed." });

  try {
    const { prompt, tool } = req.body || {};
    if (typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "Please enter a question." });
    }
    if (prompt.length > 12000) {
      return res.status(400).json({ error: "Please keep the question under 12,000 characters." });
    }

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions:
        "You are AnuCore, a friendly AI learning assistant for computer science students. " +
        "Answer clearly and accurately. For technical questions, explain concepts simply, " +
        "use examples when helpful, and format code cleanly. The selected AnuCore mode is: " +
        (typeof tool === "string" ? tool : "ASK AI") + ". Adapt the answer to that mode.",
      input: prompt.trim(),
      max_output_tokens: 1200
    });

    return res.status(200).json({
      answer: response.output_text || "I could not generate an answer this time."
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error: "AnuCore could not reach the AI service. Check the server setup and try again."
    });
  }
}
